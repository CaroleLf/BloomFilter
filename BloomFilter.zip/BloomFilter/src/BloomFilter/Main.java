package BloomFilter;

import BloomFilter.BloomArrayList;

public class Main {
    public static void main(String[] args) {
        BloomArrayList arraylistB = new BloomArrayList(10000000,4);
        arraylistB.add("marche");
        arraylistB.contains("march");
    }

}